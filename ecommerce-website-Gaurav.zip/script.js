function showProducts() {
  const products = JSON.parse(localStorage.getItem("products") || "[]");
  const container = document.getElementById("productList");
  container.innerHTML = "";
  products.forEach(p => {
    container.innerHTML += \`
      <div class="product-card">
        <img src="\${p.image}" alt="\${p.name}"><br>
        <strong>\${p.name}</strong><br>
        ₹\${p.price}
      </div>
    \`;
  });
}
showProducts();